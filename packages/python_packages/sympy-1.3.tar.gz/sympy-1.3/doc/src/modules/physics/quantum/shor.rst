================
Shor's Algorithm
================

.. automodule:: sympy.physics.quantum.shor
   :members:
