=====
Qubit
=====

.. automodule:: sympy.physics.quantum.qubit
   :members:
