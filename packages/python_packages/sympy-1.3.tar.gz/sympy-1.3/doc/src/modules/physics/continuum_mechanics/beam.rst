=================
Beam (Docstrings)
=================

Beam
====

.. automodule:: sympy.physics.continuum_mechanics.beam
   :members:
