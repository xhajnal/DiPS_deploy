==============
Tensor Product
==============

.. automodule:: sympy.physics.quantum.tensorproduct
   :members:
