====
Sets
====

.. automodule:: sympy.assumptions.handlers.sets
   :members:
