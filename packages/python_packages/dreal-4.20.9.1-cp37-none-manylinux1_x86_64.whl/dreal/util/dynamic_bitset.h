#pragma once

#include "dreal/util/dynamic_bitset.hpp"

namespace dreal {
using DynamicBitset = dynamic_bitset<size_t>;

}  // namespace dreal
