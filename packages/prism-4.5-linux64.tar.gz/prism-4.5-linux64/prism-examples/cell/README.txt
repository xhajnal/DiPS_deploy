This case study is based on a single cell in a wireless communication network. It is taken from [HMPT00].

For more information, see: http://www.prismmodelchecker.org/casestudies/cell.php

=====================================================================================

[HMPT00]
G. Haring, R. Marie, R. Puigjaner and K. Trivedi
Loss formulae and their application to optimization for cellular networks
IEEE Transaction on Vehicular Technology, 50(3):664 -673, 2000
