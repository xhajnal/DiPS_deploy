This case study is based on a cyclic server polling system, taken from [IT90].

For more information, see: http://www.prismmodelchecker.org/casestudies/polling.php

=====================================================================================

[IT90]
O. Ibe and K. Trivedi
Stochastic Petri Net Models of Polling Systems
In IEEE Journal on Selected Areas in Communications,8(9):1649-1657, 1990
