This case study is based on a simple tandem queueing network, taken from [HMKS99].

For more information, see: http://www.prismmodelchecker.org/casestudies/tandem.php

=====================================================================================

[HMKS99]
H. Hermanns, J. Meyer-Kayser and M. Siegle
Multi-Terminal Binary Decision Diagrams to Represent and Analyse Continuous Time Markov Chains
In Proc. 3rd International Workshop on the Numerical Solution of Markov Chains, pp. 188-207, 1999
