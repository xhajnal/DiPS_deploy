#include "dreal/contractor/contractor_id.h"

#include <gtest/gtest.h>

namespace dreal {
namespace {

GTEST_TEST(ContractorIdTest, Test) {
  // TODO(soonho): Add more tests.
}

}  // namespace
}  // namespace dreal
