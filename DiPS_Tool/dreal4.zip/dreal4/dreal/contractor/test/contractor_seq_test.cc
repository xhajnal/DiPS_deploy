#include "dreal/contractor/contractor_seq.h"

#include <iostream>

#include <gtest/gtest.h>

namespace dreal {
namespace {

GTEST_TEST(ContractorSeqTest, SAT) {
  // TODO(soonho): Add more tests.
}

}  // namespace
}  // namespace dreal
