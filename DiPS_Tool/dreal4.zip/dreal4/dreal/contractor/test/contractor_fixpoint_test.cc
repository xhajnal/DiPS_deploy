#include "dreal/contractor/contractor_fixpoint.h"

#include <gtest/gtest.h>

namespace dreal {
namespace {

GTEST_TEST(ContractorFixpointTest, Test) {
  // TODO(soonho): Add more tests.
}

}  // namespace
}  // namespace dreal
