#include "dreal/solver/theory_solver.h"

#include <iostream>
#include <vector>

#include <gtest/gtest.h>

namespace dreal {
namespace {

GTEST_TEST(TheorySolver, Test) {
  // TODO(soonho): Add more tests.
}

}  // namespace
}  // namespace dreal
