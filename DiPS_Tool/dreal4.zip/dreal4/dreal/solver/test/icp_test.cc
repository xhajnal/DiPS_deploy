#include "dreal/solver/icp.h"

#include <gtest/gtest.h>

namespace dreal {
namespace {

GTEST_TEST(ICP, Test) {
  // Add
}

}  // namespace
}  // namespace dreal
