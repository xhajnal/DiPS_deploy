#include "ThreadPool/ThreadPool.h"

std::atomic<int> ThreadPool::global_thread_id_index_;
