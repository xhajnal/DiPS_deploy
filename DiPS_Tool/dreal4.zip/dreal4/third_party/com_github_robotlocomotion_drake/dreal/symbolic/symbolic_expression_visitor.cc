#include "dreal/symbolic/symbolic_expression_visitor.h"

// For now, this is an empty .cc file that only serves to confirm that
// symbolic_expression_visitor.h is a stand-alone header.
