#ifndef dealii__tensor_base_h
#define dealii__tensor_base_h
#warning This file is deprecated. Use <deal.II/base/tensor.h> instead.

#  include <deal.II/base/tensor.h>

#endif
