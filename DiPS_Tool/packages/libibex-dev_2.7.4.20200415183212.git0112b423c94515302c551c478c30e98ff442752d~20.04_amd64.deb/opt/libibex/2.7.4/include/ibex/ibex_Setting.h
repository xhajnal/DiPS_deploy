/* WARNING! All changes made to this file will be lost! */

#ifndef __IBEX_SETTING_H__
#define __IBEX_SETTING_H__

#define _IBEX_RELEASE_ "2.7.4"
#define _IBEX_INTERVAL_LIB_ "FILIB"
#define _IBEX_LP_LIB_ "CLP"
#define _IBEX_WITH_AFFINE_ 1
#define _IBEX_WITH_AFFINE_EXTENDED_ 1
#define _IBEX_WITH_OPTIM_ 1
#define _IBEX_WITH_SOLVER_ 1

#endif /* __IBEX_SETTING_H__ */
